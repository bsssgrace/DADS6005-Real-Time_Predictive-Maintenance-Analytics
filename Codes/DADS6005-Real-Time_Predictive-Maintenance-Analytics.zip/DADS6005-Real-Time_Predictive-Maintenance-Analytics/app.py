import time  # to simulate a real time data, time loop

import numpy as np  # np mean, np random
import pandas as pd  # read csv, df manipulation
import plotly.express as px  # interactive charts
import streamlit as st  # 🎈 data web app development
import plotly.graph_objects as go

st.set_page_config(
    page_title="Real-Time Data Science Dashboard",
    page_icon="✅",
    layout="wide",
)

# read csv from a github repo
#dataset_url = "https://raw.githubusercontent.com/Lexie88rus/bank-marketing-analysis/master/bank.csv"

#dataset_url = pd.read_csv("yactual_and_ypredict.csv")
#yactual_and_ypredict.csv

# read csv from a URL
#@st.experimental_memo
def get_data() -> pd.DataFrame:
    #return pd.read_csv(dataset_url)
    return pd.read_csv("auc.csv")

#df = get_data()


# dashboard title
st.title("Predictive Anomaly Detection of the Air Production Unit (APU) failure")

# top-level filters
#job_filter = st.selectbox("Select the Job", pd.unique(df["job"]))

# creating a single-element container
placeholder = st.empty()

# dataframe filter
#df = df[df["job"] == job_filter]

# near real-time / live feed simulation

while True:
#for seconds in range(200):

    df = get_data()

    with placeholder.container():

        # create two columns for charts
        fig_col1, fig_col2 = st.columns(2)

        with fig_col1:
            st.markdown("### First Chart")
            fig = px.line(df, x="timestamp", y=["y_actual","y_predict"], title="Y_Actual vs. Y_Predict")
            st.write(fig)
            
        with fig_col2:
            st.markdown("### Second Chart")
            fig2 = px.line(df, x="timestamp", y=["AUC_Decision tree", "AUC_Naive Bayes", "AUC_Hoeffding Tree", "AUC_AdaBoostClassifier", "AUC_BOLEClassifier"], title="AUC 5 Model")
            st.write(fig2)

        st.markdown("### Detailed Data View")
        st.dataframe(df)
        time.sleep(1)

        


 
